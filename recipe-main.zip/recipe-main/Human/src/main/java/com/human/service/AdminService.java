package com.human.service;

import java.util.Map;

import com.human.vo.AdminVO;

public interface AdminService {

	public void register(AdminVO vo) throws Exception;
	
	public Map<String,String> signin(AdminVO vo) throws Exception;
	
	/* public void adminUpdate(AdminVO vo) throws Exception; */
	
}
