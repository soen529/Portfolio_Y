package com.human.vo;

import java.util.Date;

public class BoardVO {
	private int bno;
	private String title, userId, content, img, thumbImg;
	private Date regDate;
	
	public BoardVO() {
		super();
	}
	
	public BoardVO(int bno, String title, String userId, String content, Date regDate, String img, String thumbImg) {
		super();
		this.bno = bno;
		this.title = title;
		this.userId = userId;
		this.content = content;
		this.regDate = regDate;
		this.img = img;
		this.thumbImg = thumbImg;
	}

	public int getBno() {
		return bno;
	}

	public void setBno(int bno) {
		this.bno = bno;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public String getThumbImg() {
		return thumbImg;
	}

	public void setThumbImg(String thumbImg) {
		this.thumbImg = thumbImg;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	@Override
	public String toString() {
		return "BoardVO [bno=" + bno + ", title=" + title + ", content=" + content + ", userId=" + userId + ", regDate="
				+ regDate + ", img=" + img + ", thumbImg=" + thumbImg + "]";
	}

}
