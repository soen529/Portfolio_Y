package com.human.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(value = "/recipe")
public class RecipeController {
	
	@RequestMapping(value = "", method = RequestMethod.GET)
	public String recipe(Model model) {
		

		return "Recipes";
	}
	
	@RequestMapping(value = "/detail", method = RequestMethod.GET)
	public String recidetailjsp(Model model) {
		

		return "recidetailjsp";
	}
	
}
