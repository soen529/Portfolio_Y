package com.human.dao;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.human.vo.AdminVO;

@Repository
public class AdminDAOImpl implements AdminDAO{
	
	@Inject
	private SqlSession sql;
	
	@Override
	public void register(AdminVO vo) throws Exception {
		sql.insert("AdminMapper.register", vo);
	}

	@Override
	public int signin(AdminVO vo) throws Exception {
		return sql.selectOne("AdminMapper.signin", vo);
	}

	/*
	 * @Override public void adminUpdate(AdminVO vo) throws Exception {
	 * sql.update("adminMapper.memberUpdate", vo); }
	 */

}
