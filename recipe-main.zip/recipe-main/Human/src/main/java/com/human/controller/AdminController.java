package com.human.controller;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.human.service.AdminService;
import com.human.vo.AdminVO;

@Controller
@RequestMapping(value = "/member")
public class AdminController {
	
	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);
	
	@Inject
	AdminService service;
	
	@RequestMapping(value = "/signin", method = RequestMethod.GET)
	public void signinGet() throws Exception {
		logger.info("get signin");
	}
	
	@RequestMapping(value = "/signin", method = RequestMethod.POST)
	public @ResponseBody Map<String,String> signinPOST(@ModelAttribute AdminVO vo) throws Exception{	
		logger.info("post vo {}", vo);
		return service.signin(vo); 

	}
	
	/*
	 * @RequestMapping(value = "/signout", method = RequestMethod.GET) public String
	 * signout(HttpSession session) throws Exception{
	 * 
	 * session.invalidate();
	 * 
	 * return "redirect:/"; }
	 */
	
	
	@RequestMapping(value = "/sign-up", method = RequestMethod.GET)
	public void signUpGet() throws Exception {
		logger.info("get register");
	}
	
	@RequestMapping(value = "/sign-up", method = RequestMethod.POST)
	public String signUpPost(AdminVO vo) throws Exception {
		logger.info("post register");
		
		service.register(vo);
		
		return "member/signin";
	}
	  
	/*
	 * @RequestMapping(value="/adminUpdate", method = RequestMethod.POST) public
	 * String registerUpdate(AdminVO vo, HttpSession session) throws Exception{
	 * 
	 * service.adminUpdate(vo);
	 * 
	 * session.invalidate();
	 * 
	 * return "redirect:/";
	 * 
	 * }
	 */
	 
}
