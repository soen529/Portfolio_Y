package com.human.service;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.human.dao.AdminDAO;
import com.human.vo.AdminVO;

@Service
public class AdminServiceImpl implements AdminService {
	
	@Inject
	private AdminDAO dao;
	
	@Override
	public void register(AdminVO vo) throws Exception {
		dao.register(vo);
	}

	@Override
	public Map<String,String> signin(AdminVO vo) throws Exception {
		int count = dao.signin(vo);
		

		Map<String,String> result = new HashMap<>();
		result.put("message", "fail");
		if(count == 1) {
			result.put("message", "success");
		}
		return result;
	}

	/*
	 * @Override public void adminUpdate(AdminVO vo) throws Exception {
	 * 
	 * dao.adminUpdate(vo); }
	 */



}
