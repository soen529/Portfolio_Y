package com.human.service;

import java.util.List;

import com.human.vo.BoardVO;
import com.human.vo.SearchCriteria;

public interface BoardService {
	
	public void create(BoardVO board) throws Exception; // 게시글 등록
	public BoardVO read(int bno) throws Exception; // 게시글 조회
	public void update(BoardVO board) throws Exception; // 게시글 수정
	public void delete(int bno) throws Exception; // 게시글 삭제
	public void updateViewcnt(int bno) throws Exception; // 조회수 증가
	public List<BoardVO> listSearch(SearchCriteria cri) throws Exception; // 전체 게시글 목록
	public int listSearchCount(SearchCriteria cri) throws Exception; // 페이징 처리

}
