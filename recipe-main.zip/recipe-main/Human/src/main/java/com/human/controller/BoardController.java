package com.human.controller;

import java.io.File;
import java.util.List;

import javax.annotation.Resource;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.human.service.BoardService;
import com.human.service.ReplyService;
import com.human.utils.UploadFileUtils;
import com.human.vo.BoardVO;
import com.human.vo.PageMaker;
import com.human.vo.ReplyVO;
import com.human.vo.SearchCriteria;

@Controller
@Resource
@RequestMapping(value = "/board")
public class BoardController {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@Inject
	private BoardService service;
	
	@Inject
	ReplyService replyService;
	
	@Resource(name="uploadPath")
	private String uploadPath;
	
	@RequestMapping(value = "/boardList", method = RequestMethod.GET)
	public void boardList(@ModelAttribute("pvo") SearchCriteria pvo, Model model) throws Exception {
		System.out.println("list pvo: " + pvo);
		
		model.addAttribute("list", service.listSearch(pvo));

		PageMaker pageMaker = new PageMaker();
		pageMaker.setPvo(pvo);
		
		pageMaker.setTotalCount(service.listSearchCount(pvo));
		System.out.println("ctrl" + service.listSearch(pvo));
		model.addAttribute("pageMaker", pageMaker);
	}
	
	@RequestMapping(value = "/boardWrite", method = RequestMethod.POST)
	public String boardWritePost(BoardVO board, RedirectAttributes rttr, MultipartFile file) throws Exception {
		
		logger.info("post" + board.toString());
		
		String imgUploadPath = uploadPath + File.separator + "imgUpload";
		String ymdPath = UploadFileUtils.calcPath(imgUploadPath);
		String fileName = null;
		
		if(file.getOriginalFilename() != null && file.getOriginalFilename() != "") {
			
			fileName = UploadFileUtils.fileUpload(imgUploadPath, file.getOriginalFilename(), file.getBytes(), ymdPath);
			
			board.setImg(File.separator + "imgUpload" + ymdPath + File.separator + fileName);
			board.setThumbImg(File.separator + "imgUpload" + ymdPath + File.separator + "s" + File.separator + "s_" + fileName);
			
		} else {
			fileName = File.separator + "images" + File.separator + "none.png";
			
			board.setImg(fileName);
			board.setThumbImg(fileName);
		}
		
		service.create(board);
		System.out.println("register: " + board.toString());
		rttr.addFlashAttribute("msg", "success");
		
		return "redirect:/board/boardList";
	}
	
	@RequestMapping(value = "/boardWrite", method = RequestMethod.GET)
	public void boardWriteGet() throws Exception {		
		logger.info("get");
	}
	
	
	@RequestMapping(value = "/boardDetail", method = RequestMethod.GET)
	public String boardDetail(BoardVO vo, @RequestParam("bno") int bno, @ModelAttribute("pvo") SearchCriteria pvo, Model model) throws Exception {
		
		
		 System.out.println("vo pvo: " + pvo);
		 
		 model.addAttribute("vo", service.listSearch(pvo));
		 
		 model.addAttribute("read", service.read(vo.getBno()));
		 model.addAttribute("pvo", pvo);
		 
		model.addAttribute(service.read(bno));
		
		List<ReplyVO> replyList = replyService.readReply(vo.getBno());
		model.addAttribute("replyList", replyList);
		
		return "board/boardDetail";
	}
	
	@RequestMapping(value="/boardDelete", method=RequestMethod.POST)
	public String delete(@RequestParam("bno") int bno, SearchCriteria pvo, RedirectAttributes rttr) throws Exception {
		service.delete(bno);
		
		rttr.addAttribute("page", pvo.getPage());
		rttr.addAttribute("perPageNum", pvo.getPerPageNum());
		rttr.addAttribute("searchType", pvo.getSearchType());
		rttr.addAttribute("keyword", pvo.getKeyword());
		
		rttr.addFlashAttribute("msg", "success");
		
		return  "redirect:/board/boardList";
	}
	@RequestMapping(value="/boardUpdate", method=RequestMethod.GET)
	public void boardUpdateGet(int bno, @ModelAttribute("pvo") SearchCriteria pvo, Model model) throws Exception {
		model.addAttribute(service.read(bno));
	}
	
	@RequestMapping(value="/boardUpdate", method=RequestMethod.POST)
	public String boardUpdatePost(BoardVO board, @ModelAttribute("pvo") SearchCriteria pvo, RedirectAttributes rttr) throws Exception {
		logger.info(pvo.toString());
		service.update(board);
		
		rttr.addAttribute("page", pvo.getPage());
		rttr.addAttribute("perPageNum", pvo.getPerPageNum());
		rttr.addAttribute("searchType", pvo.getSearchType());
		rttr.addAttribute("keyword", pvo.getKeyword());
		
		rttr.addFlashAttribute("msg", "success");
		
		logger.info(rttr.toString());
		
		return "redirect:/board/boardList";
	}
	
		// 댓글 작성
		@RequestMapping(value="/replyWrite", method = RequestMethod.POST)
		public String replyWrite(ReplyVO vo, SearchCriteria pvo, RedirectAttributes rttr) throws Exception {
			logger.info("reply Write");
			
			replyService.writeReply(vo);
			
			rttr.addAttribute("bno", vo.getBno());
			rttr.addAttribute("page", pvo.getPage());
			rttr.addAttribute("perPageNum", pvo.getPerPageNum());
			rttr.addAttribute("searchType", pvo.getSearchType());
			rttr.addAttribute("keyword", pvo.getKeyword());
			
			
			return "redirect:/board/boardDetail";
		}
	
}
