package com.human.dao;

import com.human.vo.AdminVO;

public interface AdminDAO {
	public void register(AdminVO vo) throws Exception;
	
	public int signin(AdminVO vo) throws Exception;
	
	/* public void adminUpdate(AdminVO vo) throws Exception; */
}
